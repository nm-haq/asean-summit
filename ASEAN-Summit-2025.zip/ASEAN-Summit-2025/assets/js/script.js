
// assets/js/script.js
// Countdown, simple accordion, gallery lightbox, contact form demo
function qs(sel){ return document.querySelector(sel); }
function qsa(sel){ return document.querySelectorAll(sel); }

document.addEventListener('DOMContentLoaded', function(){
  // Countdown to Nov 16,2025 09:00 MYT
  const cd = qs('#countdown');
  if(cd){
    function update(){ 
      const target = new Date('2025-11-16T09:00:00+08:00');
      const now = new Date();
      const diff = target - now;
      if(diff<=0){ cd.textContent = 'Event started'; return; }
      const d = Math.floor(diff/(1000*60*60*24));
      const h = Math.floor((diff%(1000*60*60*24))/(1000*60*60));
      const m = Math.floor((diff%(1000*60*60))/(1000*60));
      cd.textContent = d + 'd ' + h + 'h ' + m + 'm';
    }
    update(); setInterval(update,60000);
  }

  // Accordion
  qsa('.accordion-toggle').forEach(btn=>{
    btn.addEventListener('click', ()=> {
      const p = btn.nextElementSibling;
      if(p.style.display === 'block') p.style.display = 'none';
      else p.style.display = 'block';
    });
  });

  // Lightbox
  qsa('.gallery-thumb').forEach(img=>{
    img.addEventListener('click', ()=> {
      const lb = qs('#lightbox');
      qs('#lightbox-img').src = img.dataset.full || img.src;
      lb.classList.remove('hidden');
    });
  });
  qs('#lightbox-close')?.addEventListener('click', ()=> qs('#lightbox').classList.add('hidden'));

  // Contact form demo
  qs('#contactForm')?.addEventListener('submit', function(e){
    e.preventDefault();
    alert('Thanks! (demo) Replace with a real backend endpoint or Formspree/Sheets integration.');
    e.target.reset();
  });

  // small accessibility: show focus outlines when tabbing
  function handleFirstTab(e){
    if(e.key === 'Tab') document.body.classList.add('user-is-tabbing');
    window.removeEventListener('keydown', handleFirstTab);
  }
  window.addEventListener('keydown', handleFirstTab);
});
