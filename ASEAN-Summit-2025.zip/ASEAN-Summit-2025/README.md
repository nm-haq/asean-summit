
# ASEAN-Summit-2025 (Mock Website)

This repository is a student project mockup for **ASEAN Summit 2025** demonstrating a multi-page, responsive website with multimedia, interactivity, and an ethics/privacy page.

## Structure
- index.html — Home (with embedded video and countdown)
- about.html — About & accessibility notes
- program.html — Schedule (accordion)
- gallery.html — Image gallery + video
- contact.html — Contact form + Google Map + register anchor
- ethics.html — Accessibility, copyright, privacy template
- assets/css/style.css
- assets/js/script.js
- assets/images/ (logo + references)

## Multimedia & Interactivity
- 2+ images (Unsplash placeholders referenced)
- Embedded YouTube video (promo)
- Embedded Google Map on Contact page
- Contact form (demo, client-side) — replace with Formspree/Sheets/backend for production
- CSS animations & JS interactivity (accordion, lightbox)

## How to use
1. Clone this repo or download the ZIP.
2. Serve locally (recommended):
   - `python -m http.server 8000` in the project root, then visit `http://localhost:8000/index.html`
3. To deploy: push to GitHub and enable **GitHub Pages** from the `main` branch (or use Netlify/Vercel).

## Notes
- Replace placeholder images with licensed media.
- Replace demo contact handling with a real backend or Formspree.
- Review and expand the privacy policy to match real data practices.
